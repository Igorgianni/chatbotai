"use client"

import  from "../middleware"

export default function SyntheticV0PageForDeployment() {
  return < />
}